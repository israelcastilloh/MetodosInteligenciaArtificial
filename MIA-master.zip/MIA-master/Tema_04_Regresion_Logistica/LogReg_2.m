%% Perceptron 1: Regresion Logistica
clear all
close all
clc
%% Cargar Datos
load LogReg2.txt;
data = LogReg2;
G0 = data(data(:,3)==0,1:2)% Grupo cero
G1 = data(data(:,3)==1,1:2)% Grupo uno
%% Grafica de los Datos
% figure(1)
% plot(G0(:,1),G0(:,2),'bo',G1(:,1),G1(:,2),'rx')
% title('Datos')
%% Regresion Logistica
X = data(:,1:2); %Variables Dependientes
Y = data(:,3); %Variables Independientes
m = size(X,1);
grado = 2;
Xa = func_polinomio(X,grado);
W = zeros(size(Xa,2),1);
[J,dJdW] = fun_costo(W,Xa,Y)
%% Optimizacion
options = optimset('GradObj','on','MaxIter',1000); % Opciones para la paqueteria
[Wopt, Jopt] = fminunc(@(W)fun_costo(W,Xa,Y),W,options)
%% Simulacion del Modelo
V = Xa*Wopt
Yg = round(1./(1+exp(-V)));
%Yg = Yg>=.5;
%% Matriz de Confunsion
TP = sum(Y==1&Yg==1);
TN = sum(Y==0&Yg==0);
FP = sum(Y==0&Yg==1);
FN = sum(Y==1&Yg==0);
Accu = (TP + TN)/(TP + TN + FP + FN);% Exactitud
Prec = (TP)/(TP+FP);% Presicion
Recall = (TP)/(TP+FN);% Recall
Results = [Accu, Prec, Recall]
%% Visualizacion de la Frontera
x1 = -1:.01:1.5;
x2 = -1:.01:1.5;
[x1,x2] = meshgrid(x1,x2);
[m,n] = size(x1);
x1temp = reshape(x1,m*n,1);
x2temp = reshape(x2,m*n,1);
xtemp = [x1temp x2temp];
Vtemp = func_polinomio(xtemp,grado)*Wopt;
Vtemp = reshape(Vtemp,m,n);
figure(2)
plot(G0(:,1),G0(:,2),'bo',G1(:,1),G1(:,2),'rx')
hold on;
contour(x1,x2,Vtemp,[0,0],'LineWidth',2);
hold off;
title('Datos y Frontera')
%%
figure(3)
bar(Wopt) %Verificar el Overfitting