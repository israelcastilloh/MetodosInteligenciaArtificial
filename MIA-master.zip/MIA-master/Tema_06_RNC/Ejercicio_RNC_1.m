%% Redes Neuronales Competitivas: Tarea 1.1
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar datos
data=xlsread('BD_RNC_1','Hoja1','A2:H91');
clasif=xlsread('BD_RNC_1','Hoja1','A96:G98');
media6 = mean(data(:,6));
desvest6 = std(data(:,6));
data(:,6) = (data(:,6)-media6)/(desvest6); % se estandariza la sexta variable
clasif(:,6) = (clasif(:,6)-media6)/(desvest6); % se estandariza la sexta variable
%% Regresi�n Log�stica
X=data(:,1:7); %Variable independiente
Y=data(:,8);
m=size(X,1);
grado=2;%grado del modelo
Xa=func_polinomio(X,grado);
W=zeros(size(Xa,2),1);
[J,dJdW]=fun_costo(W,Xa,Y);
options=optimset('GradObj','on','MaxIter',1000);
[Wopt,Jopt]=fminunc(@(W)fun_costo(W,Xa,Y),W,options); 
%% Simulaci�n del Modelo
V=Xa*Wopt;
Yg=1./(1+exp(-V));
Yg=round(Yg);
%% Medidas de Desempe�o 
TP=sum(Y==1&Yg==1);
TN=sum(Y==0&Yg==0);
FP=sum(Y==0&Yg==1);
FN=sum(Y==1&Yg==0);
Accu=(TP+TN)/(TP+TN+FP+FN);
Prec=TP/(TP+FP);
Rec=TP/(TP+FN);
[Accu Prec Rec]
%% Clasificar los datos nuevos en las categorias
Xaclass=func_polinomio(clasif,grado);
V2=Xaclass*Wopt;
Yg2=1./(1+exp(-V2));
Yg2=round(Yg2)
[a b]=func_polinomio(X,grado);