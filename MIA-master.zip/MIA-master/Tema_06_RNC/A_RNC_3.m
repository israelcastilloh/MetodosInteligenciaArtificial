%% Redes Neuronales Competitivas 3
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos2.mat;
data=RNCDatos2;
plot3(data(1,:),data(2,:),data(3,:),'.');
%% Crear la red neuronal
nn=6; %Numero de neuronas
red=competlayer(nn); %Crea la red neuronal
red.trainParam.epcohs=100; %Numero de epocas
red=train(red,data);
Wf=red.IW{1,1}';
Y=red(data);
Y=vec2ind(Y); %Convertir de vectores a indices
grupos = unique(Y); 
%%
for k=1:size(grupos,2)
    temp=data(:,Y==grupos(1,k));
    eval(['grupo' num2str(k) '=temp;']) %convertir de cadena a numero
    %%%figure(k); 
    %%%eval(['plot(grupo' num2str(grupos(1,k)) ');']);
    %eval(sprintf('grupo%d=temp;',k))
end
plot3(data(1,:),data(2,:),data(3,:),'.',Wf(1,:),Wf(2,:),Wf(3,:),'rp');