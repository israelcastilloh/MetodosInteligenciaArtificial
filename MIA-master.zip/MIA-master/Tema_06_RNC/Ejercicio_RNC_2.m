%% Redes Neuronales Competitivas: Tarea 1.2
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
data=xlsread('BD_RNC_2','Training_Data','A2:E259');
clasif=xlsread('BD_RNC_2','Clasifica','A2:E5');
clastrans=clasif';
data=data';
%% Crear la red neuronal
nn=7; %N�mero de neuronas
red=competlayer(nn); %Crea la red neuronal
red.trainParam.epochs=1000; %N�mero  de �pocas
red=train(red,data);
 
Wf=red.IW{1,1}';
Y=red(data);
Y=vec2ind(Y); %De vectores a �ndices
grupos=unique(Y)
%% Clasificacion
for k=1:size(grupos,2)
    temp=data(:,Y==grupos(1,k));
    eval(['grupo' num2str(k) '=temp;']) %para saber la cantidad de grupos que se requieren
    %eval(sprintf('grupo%d=temp;',k));
end
g_cals = red(clastrans)
grupos_clasif = vec2ind(g_cals)
% grupos
