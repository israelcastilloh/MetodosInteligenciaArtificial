%% Redes Neuronales Competitivas
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos2.mat;
data=RNCDatos2;
% load datos2.mat;
% data=datos2; %optimo son 6 grupos
%% Crear Red Neuronal
J=0; %se le da un valor inicial a la J
%plot(data(1,:),data(2,:),'.'); %se grafican los datos
nn=6; %Numero de neuronas
red=competlayer(nn); %Crear la red neuronal
red.trainParam.epochs=100; %Numero de epocas
red=train(red,data); % Entrenamiento de la red neuronal
%%
Wf=red.IW{1,1}'; %Pesos de los grupos o neuronas
Y=red(data);

Y=vec2ind(Y); %De vectores a �ndices
grupos=unique(Y); %Vector de los grupos que hay
for k=1:size(grupos,2)
    temp=data(:,Y==grupos(1,k))
%   eval(['grupo' num2str(k) '=temp;']) %como partir una frase en un comando
   eval(sprintf('grupo%d=temp;',k)); %igual que eval pero lo hace primero el texto y luego el digito
end
%%
for m=1:size(grupos,2)'
    for r=1:eval(sprintf('size(grupo%d,2)',m))
        eval(sprintf('J%d(r,1)=norm(grupo%d(:,r)-Wf(:,m))',m,m))
    end
    eval(sprintf('J%d=sum(J%d)/size(grupo%d,2);',m,m,m))
    eval(sprintf('J=J+J%d;',m))
end

J=J/size(grupos,2)
plot(data(1,:),data(2,:),'.',Wf(1,:),Wf(2,:),'rp')
%%
