%% Redes Neuronales Competitivas
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos2.mat;
data=RNCDatos2;
%% 
nn = 1;
nn_max = 10;
J_nn = [];
while nn <= nn_max
    Jg = RNC_J(nn,data);
    J(nn) = Jg;
    nn = nn+1;
end
J
%% J optima, cantidad de grupos optimos
[Jopt ind] = min(J)