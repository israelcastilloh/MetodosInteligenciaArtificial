%% Redes Neuronales Competitivas
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos1.mat;
data = RNCDatos1;
figure(1)
plot(data(1,:),data(2,:),'.');
%% Crear Red Neuronal
nn = 4; %Numero de neuronas o grupos
prom = mean(data')';
%W = [prom prom prom prom prom];
CV = 2;
W = rand(CV, nn);
eta = 0.01; %Velocidad
W0 = W; %Solo para dibujar
for nepoc=1:35 %numero de epocas
    for k = 1:size(data,2)
        for j = 1:nn
           dist(1,j) = sum((data(:,k)-W(:,j)).^2);
        end
        %determinar la menor distancia
        [val,ind] = min(dist); %valor e indice del que tiene la menor distancia
        W(:,ind) = W(:,ind)+eta*(data(:,k)-W(:,ind)); 
    end
end
Wf = W %Para Graficar y obsevar lo que sucedio con los pesos
figure(2)
plot(data(1,:),data(2,:),'b.',W0(1,:),W0(2,:),'r.',Wf(1,:),Wf(2,:),'rp')