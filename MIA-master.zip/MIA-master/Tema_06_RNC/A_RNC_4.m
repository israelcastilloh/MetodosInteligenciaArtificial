%% Redes Neuronales Competitivas 3
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos4.mat;
for k=1:35
eval(['data(:,' num2str(k) ')=BMV_' num2str(k) 'final(:,5);'])
end
temp=bsxfun(@minus,data,mean(data));
data=bsxfun(@rdivide,temp,std(data));
%% Crear la red neuronal
nn=4; %N�mero de neuronas
red=competlayer(nn); %Crea la red neuronal
red.trainParam.epcohs=100; %N�mero de �pocas
red=train(red,data);
Wf=red.IW{1,1}';
Y=red(data);
Y=vec2ind(Y); %Convertir de vectores a indices
grupos=unique(Y); 
%%
for k=1:size(grupos,2)
    temp=data(:,Y==grupos(1,k));
    eval(['grupo' num2str(k) '=temp;']) %convertir de cadena a numero
    figure(k); 
    eval(['plot(grupo' num2str(grupos(1,k)) ');']);
    %eval(sprintf('grupo%d=temp;',k))
end



