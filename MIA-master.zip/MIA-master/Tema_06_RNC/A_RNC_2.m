%% Redes Neuronales Competitivas 2
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos2.mat;
data=RNCDatos2;
figure(1)
plot3(data(1,:),data(2,:),data(3,:),'.');
%% Crear la red neuronal
nn=5; %Numero de neuronas
red=competlayer(nn); %Crear Red Neuronal de Tipo Competitiva
red.trainParam.epochs=100; % Numero de Epocas
red=train(red,data);
Wf=red.IW{1,1}';
%% Separacion de Grupos
Y=red(data);
Y=vec2ind(Y); %Comando para convertir de vectores a indices
grupos=unique(Y);
for k=1:size(grupos,2)
    temp=data(:,Y==grupos(1,k));
    eval(['grupo' num2str(k) '=temp;'])
    %eval(sprintf('grupo %d =temp;',k))
end
figure(2)
plot3(data(1,:),data(2,:),data(3,:),'.',Wf(1,:),Wf(2,:),Wf(3,:),'rp');
%%
red([8;5;1]) % va a clasificar
vec2ind(red([8;5;1])) % para saber la neurona 
grupos