%% Algotimos Geneticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% No lo lleva el PSO, es solo para graficar
x = -10:0.1:10;
y = 10 + x.^2 - 15*cos(5*x);
%% Condiciones Iniciales
np = 50; % numero de pobladores
x1p = rand(np,1)+100; % posicion inicial
%x1p = rand(np,1).*randi([-100 100],np,1); % posicion inicial aleatoria
x1pg = 0; % pocision inicial del global
fx1pg = 1000000; % desempe�o inicial del mejor global
x1pl = x1p; % valores iniciales de los mejores localesb
fx1pl = ones(np,1)*fx1pg; % desempe�o de los mejores locales
vx1 = zeros(np,1); % velocidad inicial de las particulas

c1 = 0.75; %velocidad de convergencia al mejor global
c2 = 0.75; %velocidad de convergencia al mejor local
%% Funcionamiento
for k=1:100 % iteraciones del algoritmo
    fx = 10 + x1p.^2 - 15*cos(5*x1p); % funcion a evaluar
    % minimo global
    [val, ind] = min(fx); %determinar el minimo global
    if val<fx1pg
        x1pg = x1p(ind,1); % guardar la posicion del mejor
        fx1pg = val; %guardar el valor del mejor
    end
    % minimo local
    for p=1:np
        if fx(p,1)<fx1pl(p,1);
            fx1pl(p,1) = fx(p,1); %remplazo el valor del mejor local
            x1pl(p,1) = x1p(p,1); %remplazo la posicion del mejor local
        end
    end
    %% Grafica
    plot(x,y,'b-',x1p,fx,'rx',x1pg,fx1pg,'go')
    axis([-10 10 -20 120]);
    title(['Gr�fica de la Simulacion: x1pg= ' num2str(x1pg)]);
    xlabel('x')
    ylabel('y')
    pause(.5);
    %% Ecuaciones de Movimineto
    vx1 = vx1+c1*rand()*(x1pg-x1p)+c2*rand()*(x1pl-x1p); % la velocidad
    x1p = vx1 + x1p; 
end