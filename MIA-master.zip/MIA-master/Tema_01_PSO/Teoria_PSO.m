% PSO3
%   Introducido por j. kennedy
%   Se inspira en el comportamitnro de enjambres de insectos ejemplo abejas
%   Las soluciones tienen una posiscion en el espacio de la busqueda.
%   El objetivo es que las soluciones exploren el espacio de busqueda para
%       llegar al optimo del problema, no se sabe donde esta pero sabes que 
%       tan lejos el algoritmo es un procesi iterativo en cada instante de 
%       timepo de cada particula mejor local-mejor posicion respecto al objetivo
%       mejor global_ mejor posicion de sus vecinos; Las particulas sienten 
%       atraidas hacia ambos. 
%   PROCESO-
%       *Evaluar la amplitud de cada particula
%       *Determinar las soluciones mejor local
%       *Actualizar la posicion y la velocidad de de las particulas
%       *Regresa la particula mejor evaluada
%   VENTAJAS
%       *metodo simple y extremadamente facil de implemetar
%       *no requiere de operadr�ores especializados 
%       *permite com�ntrolor facilmente la forma en que se explora el espacio
%       *se puede adaptar de acuerdo a las caracteristicas del problema
%   DESVENTAJAS
%       *no hay un analisis de convergencia general solo hay resultados para simplificaicones
%       *no se garantiza encontrar el minimo
%       *tiene problemas con problemas de no-contunuos    
% TIPS
% para que sea mas excato  es necesario
% - mas particulas
% - poner el rango  cercano en vez del rand