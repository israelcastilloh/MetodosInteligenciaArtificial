%% Algotimos Geneticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Condiciones Iniciales
np = 200; % numero de pobladores
x1p = rand(np,1)+8; % posicion inicial
%x1p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x1pg = 0; % pocision inicial del global
x1pl = x1p; % valores iniciales de los mejores locales
vx1 = zeros(np,1); % velocidad inicial de las particulas

x2p = rand(np,1)+8; % posicion inicial
%x2p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x2pg = 0; % pocision inicial del global
x2pl = x2p; % valores iniciales de los mejores locales
vx2 = zeros(np,1); % velocidad inicial de las particulas

fxpg = 1000000; % desempe�o inicial del mejor global
fxpl = ones(np,1)*fxpg; % desempe�o de los mejores locales

c1 = 0.75; %velocidad de convergencia al mejor global
c2 = 0.75; %velocidad de convergencia al mejor local
%% Funcionamiento
for k=1:100 % iteraciones del algoritmo
    fx = -20*exp(-0.2*(.5*(x1p.^2+x2p.^2).^.5))-exp(.5*(cos(2*pi*x1p)+cos(2*pi*x2p)))+exp(1)+20; % funcion a evaluar
    % minimo global
    [val, ind] = min(fx); %determinar el minimo global
    if val<fxpg
        x1pg = x1p(ind,1); % guardar la posicion del mejor
        x2pg = x2p(ind,1); % guardar la posicion del mejor
        fxpg = val; %guardar el valor del mejor
    end
    % minimo local
    for p=1:np
        if fx(p,1)<fxpl(p,1);
            fxpl(p,1) = fx(p,1); %remplazo el valor del mejor local
            x1pl(p,1) = x1p(p,1); %remplazo la posicion del mejor local
            x2pl(p,1) = x2p(p,1); %remplazo la posicion del mejor local
        end
    end
    %% Grafica
    plot(x1p,x2p,'b.',x1pg,x2pg,'go',0,0,'rx')
    axis([-10 10 -10 10]);
    title(['Gr�fica de la Simulacion: x1pg= ' num2str(x1pg) 'Gr�fica de la Simulacion: x2pg= ' num2str(x2pg)]);
    xlabel('x')
    ylabel('y')
    pause(.1);
    %% Ecuaciones de Movimineto
    vx1 = vx1+c1*rand()*(x1pg-x1p)+c2*rand()*(x1pl-x1p); % la velocidad
    x1p = vx1 + x1p;
    vx2 = vx2+c1*rand()*(x2pg-x2p)+c2*rand()*(x2pl-x2p); % la velocidad
    x2p = vx2 + x2p;
end