% La inteligencia artificial es la capacidad e los programas de un computador 
% para ejecutar de la misma forma en la que el pensamiento humano ejecuta 
% sus procesos de aprendizage y reconocimiento.
% 
% Actuan como redes neuronales, piensan como robotica el objetivo es 
% construir programas para resolver problemas dificiles.
%     ej: no sol unica/ mucha info/ info incompleta/confusa/erronea
%   2 enfoques:
%     1. fuerte: programas que imiten inteligencia humana.
%     2. debil: permitan mejorar desempe�o de campus.
%     
% Problemas que aborda: razonamiento del sentido comun / precepcion/ 
% reconocimeinto de patrones/ robotica/ analisis quimico/ oprimizacion/
% proceso del lenguaje natural.
% 
% ESTRATEGIA HEURISTICA:  es una estrategia que bsuca soluciones ante  
% grandes problemas que alguien propone.      
%   �Debe de proporcionar: soluciones suficientemente buenas/ sugerira la 
%    froma en que se ha de proceder para resolver el problema.
%   �Es frecuente en problemas de optimizacion  para maximizar y minimizar var
%   �Ejemplos: Algoritmos Geneticos y Particle Swarn Optimization        
% PARA UTILIZAR:
%   PSO
%     minimizar-( penalizacion positiva)
%     maximizar-(penalizacion negativa, multiplicar funcion -
%   AG
%     minimizar- penalizacion +, multimplicar por -1, restricciones -1
%     maximizar- penalizacion general