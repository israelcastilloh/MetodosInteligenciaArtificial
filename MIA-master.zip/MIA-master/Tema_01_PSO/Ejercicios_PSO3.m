%% Tarea 7 Ejercicios 1-3
%% Algotimos Geneticos: Con restricciones
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
format bank
%% Condiciones Iniciales
np = 400; % numero de pobladores
x1p = rand(np,1)+8; % posicion inicial
%x1p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x1pg = 100; % pocision inicial del global
x1pl = x1p; % valores iniciales de los mejores locales
vx1 = zeros(np,1); % velocidad inicial de las particulas

x2p = rand(np,1)+8; % posicion inicial
%x2p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x2pg = 0; % pocision inicial del global
x2pl = x2p; % valores iniciales de los mejores locales
vx2 = zeros(np,1); % velocidad inicial de las particulas

fxpg = 1000000; % desempe�o inicial del mejor global
fxpl = ones(np,1)*fxpg; % desempe�o de los mejores locales

c1 = 1.50; %velocidad de convergencia al mejor global
c2 = 0.75; %velocidad de convergencia al mejor local

%como el PSO busca minimizar, la penalizacion aumenta
a = -100000;
%% Funcionamiento
for k=1:50000 % iteraciones del algoritmo
    %Ejercicio 1, Comentar o descomentar
    %fx = -(2*x1p + x2p + a*max(x2p-10,0) + a*max(3*x1p + x2p - 44,0) + a*max(x1p+x2p-18,0) + a*max(2*x1p + 5*x2p - 60,0) + a*max(-x2p,0) + a*max(-x1p,0)); % funcion a evaluar
    %Ejercicio 2, Comentar o descomentar
    fx = -(5*x1p + 2*x2p + a*max(3*x1p + 2*x2p - 2400,0) + a*max(x2p-800,0) + a*max(2*x1p - 1200, 0) + a*max(-x2p,0) + a*max(-x1p,0));
    %Ejercicio 3, Comentar o descomentar
    %fx = (x1p.^4 + 2*x1p.^2 + 2*x1p.*x2p + 4*x2p.^2 - a*max(10 - 2*x1p - x2p,0) - a*max(10 - x1p - 2*x2p,0) - a*max(-x2p,0) - a*max(-x1p,0));
    % minimo global
    [val, ind] = min(fx); %determinar el minimo global
    if val<fxpg
        x1pg = x1p(ind,1); % guardar la posicion del mejor
        x2pg = x2p(ind,1); % guardar la posicion del mejor
        fxpg = val; %guardar el valor del mejor
    end
    % minimo local
    for p=1:np
        if fx(p,1)<fxpl(p,1);
            fxpl(p,1) = fx(p,1); %remplazo el valor del mejor local
            x1pl(p,1) = x1p(p,1); %remplazo la posicion del mejor local
            x2pl(p,1) = x2p(p,1); %remplazo la posicion del mejor local
        end
    end
    %Ejercicio 1, Comentar o descomentar
    %fx = 2*x1pg + x2pg
    %Ejercicio 2, Comentar o descomentar
    fx = 5*x1pg + 2*x2pg
    %Ejercicio 3, Comentar o descomentar
    %fx = x1pg^4 + 2*x1pg^2 + 2*x1pg*x2pg + 4*x2pg^2
    %% Grafica
    plot(x1p,x2p,'b.',x1pg,x2pg,'go',0,0,'rx')
    axis([-50 50 -50 50]);
    title(['Gr�fica de la Simulacion: x1pg= ' num2str(x1pg) 'Gr�fica de la Simulacion: x2pg= ' num2str(x2pg)]);
    xlabel('x1')
    ylabel('x2')
    pause(.1);
    %% Ecuaciones de Movimineto
    vx1 = vx1+c1*rand()*(x1pg-x1p)+c2*rand()*(x1pl-x1p); % la velocidad
    x1p = vx1 + x1p;
    vx2 = vx2+c1*rand()*(x2pg-x2p)+c2*rand()*(x2pl-x2p); % la velocidad
    x2p = vx2 + x2p;
end
%% Resultados de los ejercicios
% 1.- fx = 30.97
% 2.- fx = 3585.78 (�ptimo real en 3600, x1 = 600 y x2 = 300)
% 3.- fx = 176.37