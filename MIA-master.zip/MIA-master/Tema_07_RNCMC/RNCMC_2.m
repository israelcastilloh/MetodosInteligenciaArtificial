%% Redes Neuronales Competitivas MultiCapa 2 (Back Propagation)
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos4.mat;
%% Datos del Modelo
data = IPCfinal(:,5);
nsal = 8; % Numero de Salidas
nrez = 3; % Numero de Rezagos (debe ser mayor )
temp = []; %Vector para poner lo rezagos
for k = 0:nrez + nsal - 1 
    temp(:,k+1) = data(nrez+nsal-k:end-k);
end
%Para predecir a nsal d�as
Y = temp(:,1:nsal)'; 
X = temp(:,nsal+1:end)';
%% Conjunto de Etrenamiento
ndat = round(0.9*size(Y,2));
Ytrain = Y(:,1:ndat);
Xtrain = X(:,1:ndat);
Yprueba = Y(:,ndat+1:end);
Xprueba = X(:,ndat+1:end);
%% Creacion de la Red Neuronal
%no = 10; %neuronas ocultas
%nc = 6; %neuronas para la siguiente capa
%red = feedforwardnet([no,nc]); %Red de varias capas (Back Propagation), con n capas ocultas
red = feedforwardnet(10); %Red de varias capas (Back Propagation), con n capas ocultas
red.trainfcn = 'trainlm' %Fcn tarindg es el metodo de entrenamiento de gradiente descenente
%Fcn tarinlm es el metodo de entrenamiento de Leverberg-Marquart
red = train(red,Xtrain,Ytrain); %Que red, datos de entrada y de salida
Yg = red(X);
%% Grafica
nsal = size(Y,1);
for k=1:nsal
    subplot(nsal,1,k)
    plot(1:size(Y,2),Y(k,:),'b-',1:size(Yg,2),Yg(k,:),'r--')
    grid;
    title(['IPC(t+)' num2str(nsal-k+1)])
end
%% Para buscar valores
%red.IW{1,1} %pesos de entrada de la capa oculta, va a la 2 y viene de la 1
%red.b{3,1}  %bias de cada capa,
%red.LW{1,1} %pesos de salida de la capa oculta, va a la 2 y viene de la 1
%% Para Predecir con Datos Dados
%red([12,15,18]'); %debe ser del tama�o de los rezagos(dato hoy, ayer, antier,......)