%% Redes Neuronales Competitivas
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load thyroid_dataset.mat;
%Y = thyroidTargets;
X = thyroidInputs;
%% Convertir Salidas Binarias en Enteras
for j = 1:size(thyroidTargets,2)
    for i=1:3
        if thyroidTargets(i,j)==1
            Y(1,j)=i;
        end
    end
end
%% Conjunto de Entrenamiento y Prueba
ndat = round(0.9*size(Y,2));
Ytrain = Y(:,1:ndat);
Xtrain = X(:,1:ndat);
Yprueba = Y(:,ndat+1:end);
Xprueba = X(:,ndat+1:end);
%% Crear Red Neuronal
red = feedforwardnet(10); %Red de varias capas (Back Propagation), con n capas ocultas
red.trainFCn = 'trainscg'; %Fcn tarindg es el metodo de entrenamiento de Gradiente EScalar
red = train(red,Xtrain,Ytrain);
Yg = red(Xtrain);
Yg = round(Yg);
%Este modelo permite clasificar
%% Medidas de Desempe�o de Entrenamiento
TP=sum(Ytrain==1&Yg==1);
TN=sum(Ytrain==0&Yg==0);
FP=sum(Ytrain==0&Yg==1);
FN=sum(Ytrain==1&Yg==0);
accuracy=(TP+TN)/(TP+TN+FP+FN);
precision=TP/(TP+FN);
recall=TP/(TP+FP);
f1=2*((precision*recall)/(precision+recall));
MD=[accuracy precision recall f1]
%% Medidas de Desempe�o de Prueba
Yg = red(Xprueba);
Yg = round(Yg);
TP=sum(Yprueba==1&Yg==1);
TN=sum(Yprueba==0&Yg==0);
FP=sum(Yprueba==0&Yg==1);
FN=sum(Yprueba==1&Yg==0);
accuracy=(TP+TN)/(TP+TN+FP+FN);
precision=TP/(TP+FN);
recall=TP/(TP+FP);
f1=2*((precision*recall)/(precision+recall));
MD=[accuracy precision recall f1]
