%% Redes Neuronales Competitivas MultiCapa (Back Propagation)
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% PRIMER PROBLEMA
% Considere la base de datos contenida en el archivo house.mat. 
% Los renglones del 1 al 13 contienen informaci�n estad�stica de 506 
% vecindarios que ser� usada para estimar el precio medio de las casas en 
% miles de d�lares (Rengl�n 14).
% Las 13 variables (respetando el idioma original son) son:
%   1)      Per capita crime rate per town
%   2)      Proportion of residential land zoned for lots over 25,000 sq. ft. 
%   3)      Proportion of non-retail business acres per town
%   4)      1 if tract bounds Charles river, 0 otherwise. 
%   5)      Nitric oxides concentration (parts per 10 million)
%   6)      Average number of rooms per dwelling
%   7)      Proportion of owner-occupied units built prior to 1940
%   8)      Weighted distances to five Boston employment centers
%   9)      Index of accessibility to radial highways
%   10)   Full-value property-tax rate per $10,000
%   11)   Pupil-teacher ratio by town
%   12)   1000(Bk - 0.63)^2, where Bk is the proportion of blacks by town
%   13)   Percent lower status of the population

% a) Utilice el 90% de los datos para entrenar el modelo neuronal y 
% estime el 10 % restante
% b) Estime el precio medio en miles de d�lares de una casa en la cual se 
% tienen los siguientes par�metros:
% X1= 12.54, X2=45, X3=15.37, X4=1, X5=0.5150, X6=6.1621, X7=45.800, X8=3.3751, X9=7, X10=193, X11=15.200, X12=347.88, X13=2.96
%% Cargar Datos
load house.mat;
%% Datos del Modelo
X = house(1:13,:);
Y = house(14,:);
%% Conjunto de Entrenamiento y Prueba
ndat = round(0.9*size(Y,2));
Ytrain = Y(:,1:ndat);
Xtrain = X(:,1:ndat);
Yprueba = Y(:,ndat+1:end);
Xprueba = X(:,ndat+1:end);
%% Creacion de la Red Neuronal
no = 10; %neuronas ocultas
nc = 6; %neuronas para la siguiente capa
%red = feedforwardnet([no,nc]); %Red de varias capas (Back Propagation), con n capas ocultas
red = feedforwardnet(10); %Red de varias capas (Back Propagation), con n capas ocultas
red.trainfcn = 'trainlm'; %Fcn tarindg es el metodo de entrenamiento de gradiente descenente
%Fcn tarinlm es el metodo de entrenamiento de Leverberg-Marquart
red = train(red,Xtrain,Ytrain); %Que red, datos de entrada y de salida
Yg = red(Xtrain);
%% Prediccion inciso a)
pred1 = Xprueba; %Datos a predecir
red(pred1);
%% Prediccion inciso b)
pred1 = [12.54,45,15.37,1,0.5150,6.1621,45.800,3.3751,7,193,15.200,347.88,2.96]'; %Datos a predecir
red(pred1) %Resultado de la prediccion
%% Grafica
plot(1:size(Ytrain,2),Ytrain,'bo',1:size(Yg,2),Yg,'ro')
%% SEGUNDO PROBLEMA
% Cargue la base de datos con nombre BD_2.mat. En la base encontrar�
% una matriz de nombre train, con ejemplos de datos que ya fueron 
% clasificados, con la cual deber� entrenar una red neuronal para llevar a 
% cabo una clasificaci�n supervisada para clasificar los datos contenidos 
% en la matriz test_unknown.
% a)      Es altamente probable que su primer intento no funcione. 
% �Cu�l es el error que impide clasificar los datos y c�mo se corrige?
% b)      Usando �nicamente una neurona en la capa de salida proporcione la
% clasificaci�n de los datos de la matriz test_unknown.
% c)      Usando tres neuronas en la capa de salida proporciones la 
% clasificaci�n de los datos de la matriz test_unknown.
% d)      Compare las clasificaciones obtenidas en el inciso b) y c). 
% �Se le asigna la misma clasificaci�n por ambos m�todos? Justifique su respuesta.
%% Limpieza
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load BD_2.mat;
%% Datos del Modelo
train2 = train;
X = train2(:,1:3)';
Y = train2(:,4)';
clear train
% a) Es altamente probable que su primer intento no funcione. �Cu�l es el error que impide clasificar los datos y c�mo se corrige?
% R.- El nombre de la matriz de datos es 'train' y eso choca con la palabra
% reservada de los modelos de redes neuronales para entrenar un modelo.
%% Creacion de la Red Neuronal (inciso b))
no = 10; %neuronas ocultas
nc = 6; %neuronas para la siguiente capa
%red = feedforwardnet([no,nc]); %Red de varias capas (Back Propagation), con n capas ocultas
red = feedforwardnet(10); %Red de varias capas (Back Propagation), con n capas ocultas
red.trainfcn = 'trainscg'; %Fcn tarindg es el metodo de entrenamiento de gradiente descenente
%Fcn tarinlm es el metodo de entrenamiento de Leverberg-Marquart
red = train(red,X,Y); %Que red, datos de entrada y de salida
Yg_res = red(X);
%% Prediccion (inciso b)
pred1 = test_unknown'; %Datos a predecir
a = round(red(pred1)); %Resultado de la prediccion
%% Transformacion de las Salidas (inciso c))
Y2 = [];
for j = 1:size(Y,2)
    if Y(1,j) == 1
        Y2(1,j) = 1;
    else 
        Y2(1,j) = 0;
    end
    if Y(1,j) == 2
        Y2(2,j) = 1;
    else 
        Y2(2,j) = 0;
    end
    if Y(1,j) == 3
        Y2(3,j) = 1;
    else 
        Y2(3,j) = 0;
    end
end
%% Crear Red Neuronal
red = feedforwardnet(10); %Red de varias capas (Back Propagation), con n capas ocultas
red.trainFCn = 'trainscg'; %Fcn tarindg es el metodo de entrenamiento de Gradiente EScalar
red = train(red,X,Y2);
Yg = red(X);
Yg = round(Yg);
%Este modelo permite clasificar
%% Medidas de Desempe�o de Prueba
pred1 = test_unknown'; %Datos a predecir
Yg = red(pred1);
b = round(Yg);
%% Transformaci�n de Resultados para comparar
for j = 1:size(b,2)
    for i=1:3
        if b(i,j)==1
            c(1,j)=i; %nuevos resultados
        end
    end
end
%% Comparacion de Resultados (inciso d))
d = a-c;
sum(d)