%% Algotimos Gen�ticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Supuestos
%Poblacion multiplo de 4
%% C�digo
nbits = 8; %Cantidad de bits
np = 8; %n�mero de pobladores
%% Generar poblaci�n
xpadres = randi([0,255],np,1); %Aqu� se genera una poblaci�n aleatoria de acuerdo al n�mero de pobladores
%% Evaluaci�n de la Funci�n
for n=1:100 %Se hacen 100 corridas
    y = xpadres.^2; %esta es la funci�n del modelo simulado
    yprom(n) = mean(y); %aqu� se guardan los promedios de las simulaciones
%% Cromosoma
    cromosoma = sortrows([xpadres y],2); %Aqui se ordena y se crean los cromosomas
%% Selecci�n
    padresbin = de2bi(cromosoma(np/2+1:np,1),nbits); %aqui se seleccionan los padres
%% Cruzamiento
    for k=1: (nbits/4) %cliclo se mexclan los padres
        n = randi([2,nbits-1]);
        hijobin(2*k-1,:)=[padresbin(2*k-1,1:n) padresbin(2*k,n+1:nbits)]; %se hace el hijo 1
        hijobin(2*k,:)=[padresbin(2*k,1:n) padresbin(2*k-1,n+1:nbits)]; %se hace el hijo 2
    end
    %% Mutaci�n
    n = rand(); %se crea un valor aleatorio de 0-1
    if n>=.8 %este ciclo hace que solo se mute el 20% de los casos
        nhijo = randi(np/2); %se selecciona el hijo
        nbit = randi(nbits); %se selecciona el bit que mutara
        if hijobin(nhijo,nbit)== 1 %ciclo con condiciones de mutaci�n
            hijobin(nhijo,nbit)= 0;
        else
            hijobin(nhijo,nbit)= 1;
        end
    end
    hijodec = bi2de(hijobin); %Convierte de binario a decimal
    xpadres = [cromosoma(np/2+1:np,1); hijodec]; %Sustituci�n de poblaci�n
end
plot(yprom); %Se grafican los promedios de la y
xlabel('x')
ylabel('y')
title('Gr�fica de la Simulaci�n')
max(y); %guarda el m�ximo valor de y

        
