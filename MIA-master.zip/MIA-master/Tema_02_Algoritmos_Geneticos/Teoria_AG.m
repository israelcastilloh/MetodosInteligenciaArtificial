% ALGORITMOS GENETICOS
% Creador: jhon holland
%     Buenos para:
%       *problemas discretos( n naturales,123)
%       *son probabilisticos
%       *busqueda en paralelo
%       *no rapidos
%       *se basan en seleccion natural y genetica
%    Ventajas:
%       *resolver problemas de grandes soluciones
%       *conjunt de puntos
%       *paralelos
%       *multiobjetivo
%    Desventajas
%       *no buen plantamiento objetivo
%       *convergencia prematura que causa SUPERINDIVIDUOS
%       *lentos a la hora de aplicar en problemas resolubles de manera analitica
%    Requisitos para usar un AG:     
%       1. espacio de busqyeda delmitado
%       2. funcion de apmplitud que indique que tan buena o mala es euna respuesta
%       3. solucines codificables
%    Aplicaciones:
%       optimizacion, programacion automatica aprendizaje de maquina, 
%       economia,finanzas, sistemas inmunes, genetica de poblaciones,
%       evoulcion y aprendizaje, sistemas sociales.
%    Funcinamiento:
%       *representacion apropiada
%       *poblacion inicial
%       *funcion de evaluacion
%       *conjunto de operadores evolutivos
%       *parametros de entradas
%    FENOTIPO: 
%       *evaluar a cada individuo con la funcion objetivo  
%    3 tipos de Operadores Geneticos
%       *Seleccion --> transmitir las caracteriticas de las soluciones valiosas
%       *Cruce --> permite intercambiar info para mejores resulyados
%           �de punto/ n punto/ uniforme/aritmetico/permutacion/
%       *Mutacion   
% RESUMEN:
% 1 poblacion inicial 
%     codificacion
%     seleccion de paraetros
% 2. operadores geneticos
%     seleccion/ cruzamineto/ mutacion
% 3. sustitucion general
