%% Algotimos Gen�ticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Problema
% Algoritmo Gen�tico Modificado.  Desarrollar un algoritmo gen�tico que 
%cumpla con los siguientes requisitos: 
    % El algoritmo debe trabajar s�lo con n�meros enteros positivos.
    % Poblaci�n: inicial de 32 individuos.
    % Selecci�n: Ordenar la poblaci�n de acuerdo a su desempe�o.
    % Seleccionar de 2 en 2 y hacer un torneo donde el individuo que 
        % tenga mejor desempe�o se le d� una probabilidad de selecci�n del 
        % 80% y al peor de un 20%.
    % Cruzamiento: Del conjunto de Padres seleccionar aleatoriamente 3 de 
        % ellos, no importa su repetici�n. Generar un cruce a dos puntos de 
        % cruce con la siguiente configuraci�n Padre1|Padre2|Padre3.  Los  
        % puntos de cruce se deben determinar de forma aleatoria para cada 
        % uno de los hijos. Repetir el proceso hasta producir la mitad de 
        % hijos que la poblaci�n inicial.
% Agregar los hijos al conjunto de padres y repetir el proceso.
% Mutaci�n: Usar una probabilidad de mutaci�n del 10% y en lugar de mutar 
% un bit, mutar tre bits del individuo.
% Generaciones: 1000
% Con el algoritmo desarrollado obtener el m�ximo de la funci�n: 
% y = -(x-628)2 + 20 para x ?[1,1024].
%% Supuestos
%Poblacion multiplo de 4
%% C�digo
xmax = 1024; %(2 a la n) -1
xmin = 1;
tpaso = 1;
num_ele = (xmax-xmin+1)/tpaso;
nbits = ceil(log2(num_ele));
np = 32; %n�mero de pobladores
%% Generar poblacion
xpadres = randi([0,(2^nbits)-1],np,1); %Pobladores iniciales enteros
xpadresreal = ((xmax-xmin)*xpadres/((2^nbits)-1))+xmin; %Pobladores iniciales en n�meros reales
for i=1:1000
    y = (-((xpadresreal-628).^2)+20);
    yprom(i) = mean(y);
    %% Cromosoma
    cromosoma = [xpadres xpadresreal y];
    cromosoma = sortrows(cromosoma,size(cromosoma,2));
    for j=1:np/2
        m = rand();
        if m>.2
            padredec(j,1) = cromosoma(2*j,1);
        else
            padredec(j,1) = cromosoma(2*j-1,1);
        end
    end
    %% Selecccion 
    padresbin = de2bi(padredec,nbits); % Selecci�n de los mejores y conversi�n a binario
    %% Cruzamiento
    hijobin = metodocruzamiento(padresbin,np,nbits,4);
    for h = 1 : np/2
        p1 = randi([1,16]); %padres 1
        p2 = randi([1,16]); %padres 2
        p3 = randi([1,16]); %padres 3
        c1 = randi([2 nbits-2]); %punto de cruce
        c2 = randi([c1+1 nbits-1]); %punto de cruce
        for k=1:(np/4)
            p=randi([2,nbits-1]); %el primero y el ultimo no me sirve
            hijobin(2*k-1,:)=[padresbin(2*k-1,1:p) padresbin(2*k,p+1:nbits)];
            hijobin(2*k,:)=[padresbin(2*k,1:p) padresbin(2*k-1,p+1:nbits)];
        end
    %% Mutaci�n
        g = rand();
        if g>=0.90
            nhijo = randi(np/2);
            for f = 1:3
            nbit1 = randi(nbits-1);
                if hijobin(nhijo,nbit1)== 1
                    hijobin(nhijo,nbit1)= 0;
                else
                    hijobin(nhijo,nbit1)= 1;
                end
            end
        end
    end
        hijoent = bi2de(hijobin); %Convierte de binario a decimal
        hijoreal = (((xmax - xmin)*hijoent)/((2^nbits)-1)) + xmin; %Convierte de binario a decimal
        %% Sustituci�n
        xpadres = [padredec; hijoent]; %Sustituci�n generada
        xpadresreal = [padredec; hijoreal];      
end
y = (-((xpadresreal-628).^2)+20);
cromosoma = [xpadres xpadresreal y];
[val,ind] = max(y);
disp(["Resultado xpadresreal: ", num2str(cromosoma(ind,2))])
disp(["Resultado y: ", num2str(val)])
%% 
plot(yprom); %Se grafican los promedios de la y
xlabel('x')
ylabel('y')
title('Gr�fica de la Simulaci�n')
max(y); %guarda el m�ximo valor de y