% y = metodocruzamiento(padresbin,np,nbits)
% padresbin es el conjunto de padres en binario
% np son la cantidad de pobladores
% nbits es la cantidad de bits
% n es el n�mero de caso
function y = metodocruzamiento(padresbin,np,nbits,n)
switch n
    case 1 % Cruzamiento a un punto de cruce
        for k=1: (np/4)
            p = randi([2,nbits-1]);
            hijobin(2*k-1,:)=[padresbin(2*k-1,1:p) padresbin(2*k,p+1:nbits)];
            hijobin(2*k,:)=[padresbin(2*k,1:p) padresbin(2*k-1,p+1:nbits)];
        end
        y = hijobin;
    case 2 % Dos puntos de cruce
        for k=1:(np/4)
            p1 = randi([2,nbits-2]);
            p2 = randi([p1+1,nbits-1]);
            hijobin(2*k-1,:)=[padresbin(2*k-1,1:p1) padresbin(2*k,p1+1:p2) padresbin(2*k-1,p2+1:nbits)];
            hijobin(2*k,:)=[padresbin(2*k,1:p1) padresbin(2*k-1,p1+1:p2) padresbin(2*k,p2+1:nbits)];
        end
        y = hijobin;
    case 3 % Cruce Aritm�tico
        padresbin = bi2de(padresbin);
        for k=1:(np/2)
            b = k+1;
            if b>(np/2)
                b = 1;
            end
            hijobin(k,:)=[ceil((padresbin(k,1)+padresbin(b,1))/2)];
        end
        y = de2bi(hijobin);
    case 4 % Cruce Uniforme
        %mascara
        %masc=zeros(1,nbits);
        %positions=[1:2:nbits];
        %masc(positions) = 1;
        %masc = [0 0 1 1 0 0 0 0 0 0 0];
        masc = randi([0 1], 1, nbits);
        % cruzamiento
        for k=1:(np/2)
            b = k+1;
            if b>(np/2)
                b = 1;
            end
            for z=1:length(masc)
                if masc(z)==1
                    hijobin(k,z)= padresbin(k,1);
                else
                    hijobin(k,z)= padresbin(b,1);
                end
            end   
        end    
        y = hijobin;
    otherwise 
        disp('Escribiste algo fuera de rango. Recuerda que solo acepta el numero 1 (un punto de cruce), 2 (dos puntos de cruce), 3 (cruce uniforme), 4 (cruce aritmetico)')
end