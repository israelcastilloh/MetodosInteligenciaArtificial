%% Algotimos Gen�ticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Supuestos
%Poblacion multiplo de 4
%% C�digo
xmax = 5.12;
xmin = -5.12;
tpaso = 0.01;
num_ele = (xmax-xmin+1)/tpaso;
nbits = ceil(log2(num_ele));
xmax2 = 5.12;
xmin2 = -5.12;
tpaso2 = 0.01;
num_ele2 = (xmax2-xmin2+1)/tpaso2;
nbits2 = ceil(log2(num_ele));
np = 256; %n�mero de pobladores
%% Generar poblacion
xpadres = randi([0,(2^nbits)-1],np,1); %Pobladores iniciales enteros
xpadresreal = ((xmax-xmin)*xpadres/((2^nbits)-1))+xmin; %Pobladores iniciales en n�meros reales
xpadres2 = randi([0,(2^nbits2)-1],np,1); %Pobladores iniciales enteros
xpadresreal2 = ((xmax2-xmin2)*xpadres2/((2^nbits2)-1))+xmin2; %Pobladores iniciales en n�meros reales
for i=1:100
    y = -(20+xpadresreal.^2-10*cos(2*pi*xpadresreal)+xpadresreal2.^2-10*cos(2*pi*xpadresreal2));
    yprom(1,i) = mean(y);
    %% Cromosoma
    cromosoma = [xpadres xpadresreal xpadres2 xpadresreal2 y];
    cromosoma = sortrows(cromosoma,size(cromosoma,2));
    %% Selecccion 
    padresbin = de2bi(cromosoma((np/2)+1:np,1),nbits); % Selecci�n de los mejores y conversi�n a binario
    padresbin2 = de2bi(cromosoma((np/2)+1:np,3),nbits); % Selecci�n de los mejores y conversi�n a binario
    padresbin3 = de2bi(cromosoma((np/2)+1:np,5),nbits); % Selecci�n de los mejores y conversi�n a binario
    %% Cruzamiento
    hijobin = metodocruzamiento(padresbin,np,nbits,5);
    hijobin2 = metodocruzamiento(padresbin2,np,nbits2,5);
    hijobin3 = metodocruzamiento(padresbin3,np,nbits2,5);
    %% Mutaci�n
        g = rand();
        if g>=0.85
            nhijo = randi(np/2);
            nbit = randi(nbits-1);
            if hijobin(nhijo,nbit)== 1
                hijobin(nhijo,nbit)= 0;
            else
                hijobin(nhijo,nbit)= 1;
            end
            
            
        end
        h = rand();
        if h>=0.85
            nhijo = randi(np/2);
            nbit = randi(nbits2-1);
            if hijobin2(nhijo,nbit)== 1
                hijobin2(nhijo,nbit)= 0;
            else
                hijobin2(nhijo,nbit)= 1;
            end
        end
        hijoent = bi2de(hijobin); %Convierte de binario a decimal
        hijoreal = (((xmax - xmin)*hijoent)/((2^nbits)-1)) + xmin; %Convierte de binario a decimal
        
        hijoent2 = bi2de(hijobin2); %Convierte de binario a decimal
        hijoreal2 = (((xmax2 - xmin2)*hijoent2)/((2^nbits2)-1)) + xmin2; %Convierte de binario a decimal
        
        xpadres = [cromosoma(np/2+1:np,1); hijoent]; %Sustituci�n generada
        xpadresreal = [cromosoma(np/2+1:np,2); hijoreal];
        
        xpadres2 = [cromosoma(np/2+1:np,3); hijoent2]; %Sustituci�n generada
        xpadresreal2 = [cromosoma(np/2+1:np,4); hijoreal2];
end
y = -(20+xpadresreal.^2-10*cos(2*pi*xpadresreal) + xpadresreal2.^2-10*cos(2*pi*xpadresreal2));
cromosoma = [xpadres xpadresreal xpadres2 xpadresreal2 y];
[val,ind] = max(y);
disp(["Resultado xpadresreal: ", num2str(cromosoma(ind,2))])
disp(["Resultado xpadresreal2: ", num2str(cromosoma(ind,4))])
disp(["Resultado y: ", num2str(val)])
%% 
plot(yprom); %Se grafican los promedios de la y
xlabel('x')
ylabel('y')
title('Gr�fica de la Simulaci�n')
max(y); %guarda el m�ximo valor de y