%% Algotimos Gen�ticos
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Supuestos
%Poblacion multiplo de 4
%
%% C�digo
xmax = 50;
xmin = -50;
tpaso = 0.2;
num_ele = (xmax-xmin+1)/tpaso;
nbits = ceil(log2(num_ele));
np = 16; %n�mero de pobladores
%% Generar poblacion
xpadres = randi([0,(2^nbits)-1],np,1); %Pobladores iniciales enteros
xpadresreal = ((xmax-xmin)*xpadres/((2^nbits)-1))+xmin; %Pobladores iniciales en n�meros reales
for n=1:100
    y = -((xpadresreal + 40.2).^2 )+ 100;
    yprom(n) = mean(y);
    %% Cromosoma
    cromosoma = [xpadres xpadresreal y];
    cromosoma = sortrows(cromosoma,size(cromosoma,2));
    %% Selecccion 
    padresbin = de2bi(cromosoma((np/2)+1:np,1),nbits); % Selecci�n de los mejores y conversi�n a binario
    %% Cruzamiento
    hijobin = metodocruzamiento(padresbin,np,nbits,2)
    %% Mutaci�n
        n = rand();
        if n>=0.85
            nhijo = randi(np/2);
            nbit = randi(nbits);
            if hijobin(nhijo,nbit)== 1
                hijobin(nhijo,nbit)= 0;
            else
                hijobin(nhijo,nbit)= 1;
            end
        end
        hijoent = bi2de(hijobin); %Convierte de binario a decimal
        hijoreal = (((xmax - xmin)*hijoent)/((2^nbits)-1)) + xmin; %Convierte de binario a decimal
        
        xpadres = [cromosoma(np/2+1:np,1); hijoent]; %Sustituci�n generada
        xpadresreal = [cromosoma(np/2+1:np,1); hijoreal];
end
y = -((xpadresreal + 40.2).^2 )+ 100;
cromosoma = [xpadres xpadresreal y];
[val,ind] = max(y);
disp(["Resultado xpadresreal: ", num2str(cromosoma(ind,2))])
disp(["Resultado y: ", num2str(val)])