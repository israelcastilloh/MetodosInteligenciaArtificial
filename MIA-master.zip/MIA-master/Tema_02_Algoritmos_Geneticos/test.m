nbits=8; %Numeros de bits
p1=randi([2, nbits-4])
p2=randi([p1+1, nbits-2])
p3=randi([p2+1, nbits])




