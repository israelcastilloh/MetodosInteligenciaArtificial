%% Problema 2 Tarea 1: Adaline
clear all;
close all;
clc;

%%
datos = xlsread('regresion','Problema 2','A2:C201');
X1 = datos(:,1);
X2 = datos(:,2);
Y = datos(:,3);
%% M�NIMOS CUADRADOS
n=size(Y,1); %Cantidad de Datos
Xa= [ones(n,1)]; %Primer columna de Xa

%Construir Xa
for i=1:2
    grado=i;
    Xa = func_polinomio([X1,X2],i); %bias (tiene la estructura del polinomio)
    Wmc=inv(Xa'*Xa)*Xa'*Y; %M�nimos cuadrados
    Yg_mc=Xa*Wmc; %Y testada estimada a trav�s de m�nimos cuadrados
    E=Y-Yg_mc; %Error
    J(i,1) = (E'*E)./(2*n); %Funci�n de costo 
end


subplot(2,1,1);
plot(Xa,Y,'b.',Xa,Yg_mc,'r.');
subplot(2,1,2)
plot(J,'b-');
xlabel('Grado del polinomio');
ylabel('J(W,X)');
J(grado)