
%PSO (Particle Swarm Optimization) with Parametric Restrictions 

clear all;
close all;
clc;

np=1000; %n�mero de part�culas

x1p=rand(np,1); % inicializaci?n
x1pg=0; %valor inicial del mejor global
x1pL=x1p; %valores inciales de mejores locales
vx1=zeros(np,1);  %velocidad del enjambre

x2p=rand(np,1); % inicializaci?n
x2pg=0; %valor inicial del mejor global
x2pL=x1p; %valores inciales de mejores locales
vx2=zeros(np,1);  %velocidad del enjambre


fxpg=10000; %mejor desempe�o inicial
fxpL=ones(np,1)*fxpg; %desempe�o local inicial


c1=0.80; %Velocidad de convergencia
c2=0.80; %velocidad de convergencia

%%
a = 1000; %se hace negativo al maximizar y solo la funci�n en negativo

for i=1:100 %N�mero de generaciones
    fx= -((x1p*.05 + x2p*.10) - sqrt(x1p.^2*.05 + x2p.^2*.05)) + a*abs(x1p + x2p-1)...
         +a*abs(x1p*20000+x2p*30000-50000)...
         +a*max(-x1p,0)+a*max(-x2p,0)...
         +a*max(-x1p*.05 - x2p*.10 + 0.05,0)...
         +a*max(x1p-1,0) + a*max(x2p-1,0);
       %funci�n de desempe�o con restricciones
    
    [val,ind] = min(fx);
    
    if val<fxpg %Actualizaci�n del mejor global
        x1pg=x1p(ind,1); %Posici�n
        x2pg=x2p(ind,1);
        fxpg=val; %Desempe�o 
    end
    
    for p=1:np
        if fx(p,1)<fxpL(p,1)
            fxpL(p,1)=fx(p,1); %se actualiza el desempe�o del local
            x1pL(p,1)=x1p(p,1); %se actualizan las nuevas posiciones del local ********** (duda)  *******
            x2pL(p,1)=x2p(p,1);
        end
    end    

    plot(x1p, x2p, 'bo', x1pg, x2pg, 'go')
    axis([0 2 0 2]);
    title(['x1pg= ' num2str(x1pg) ' x2pg= ' num2str(x2pg)]);
    pause(0.1);
    
    %Ecuaciones de movimiento
    
   %Ecuaciones de movimiento
    vx1=vx1+c1*rand(np,1).*(x1pg-x1p)+c2*rand()*(x1pL-x1p);
    x1p=x1p+vx1;
%rand(np,1). sirve para darle una velocidad diferente a cada particula

    vx2=vx2+c1*rand(np,1).*(x2pg-x2p)+c2*rand()*(x2pL-x2p);
    x2p=x2p+vx2;
            
end         

risk=sqrt(x1pg.^2*.05 + x2pg.^2*.05)
ret=x1pg*.05 + x1pg*.10