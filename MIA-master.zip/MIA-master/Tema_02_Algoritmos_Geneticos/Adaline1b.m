clear all;
close all;
clc;

res=downloadValues('CMG', '03/10/2015', '03/10/2016', 'd', 'history');
precios=res.AdjClose; %Elige el adjacent close de res

nrez=3; %N�mero de rezagos en el tiempo

X=[];

for k=0:nrez
    X=[X, precios(nrez+1-k:end-k)];
end   

Y=X(:,1); %La salida del modelo
Xa=[ones(size(X,1),1) X(:,2:end)];

ntrain=round(0.6*size(Xa,1));

Xa_train=Xa(1:ntrain,:);
Y_train=Y(1:ntrain,:);

Xa_test=Xa(ntrain+1:end,:);
Y_test=Y(ntrain+1:end,:);

Wmc=inv(Xa_train'*Xa_train)*Xa_train'*Y_train;
Yg_mc=Xa*Wmc; %Modelo por m�nimos cuadrados 

Yg_rec=Xa_train*Wmc; %Simulaci�n de los datos conocidos
Xtemp=Xa_train(end,:); %Los datos mas recientes para estimar el siguiente dato

for k=ntrain+1:size(Xa,1);
    Xtemp=[1 Yg_rec(k-1,1) Xtemp(:,2:end-1)];
    Yg_rec(k,1)=Xtemp*Wmc;
end


plot([1:size(Y,1)]',Y,'b-', [1:size(Yg_mc,1)]',Yg_mc,'r-', [1:size(Yg_rec,1)]',Yg_rec,'g-')



