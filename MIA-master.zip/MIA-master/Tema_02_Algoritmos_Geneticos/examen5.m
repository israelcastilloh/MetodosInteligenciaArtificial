clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Condiciones Iniciales
np = 200; % numero de pobladores
x1p = rand(np,1)+8; % posicion inicial
%x1p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x1pg = 0; % pocision inicial del global
x1pl = x1p; % valores iniciales de los mejores locales
vx1 = zeros(np,1); % velocidad inicial de las particulas

x2p = rand(np,1)+8; % posicion inicial
%x2p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x2pg = 0; % pocision inicial del global
x2pl = x2p; % valores iniciales de los mejores locales
vx2 = zeros(np,1); % velocidad inicial de las particulas

x3p = rand(np,1)+8; % posicion inicial
%x2p = rand(np,1).*randi([-10 10],np,1); % posicion inicial aleatoria
x3pg = 0; % pocision inicial del global
x3pl = x3p; % valores iniciales de los mejores locales
vx3 = zeros(np,1); % velocidad inicial de las particulas

fxpg = 1000000; % desempe�o inicial del mejor global
fxpl = ones(np,1)*fxpg; % desempe�o de los mejores locales

c1 = 0.75; %velocidad de convergencia al mejor global
c2 = 0.75; %velocidad de convergencia al mejor local


%% Funcionamiento
a= 1000;
for k=1:1000 % iteraciones del algoritmo
    fx= -(4*x1p+12*x2p+2*x3p) + ...
        a*max(3*x1p+6*x2p+2*x3p-600,0)+...
        a*max(-x1p-x2p-x3p+240,0)+...
        a*max(x3p-140,0)+...
        a*max(-x2p+1,0)+...
        a*max(-x1p,0)+...
        a*max(-x2p,0)+...
        a*max(-x3p,0);
        
    % minimo global
    [val, ind] = min(fx); %determinar el minimo global
    if val<fxpg
        x1pg = x1p(ind,1); % guardar la posicion del mejor
        x2pg = x2p(ind,1); % guardar la posicion del mejor
        x3pg = x3p(ind,1); % guardar la posicion del mejor
        fxpg = val; %guardar el valor del mejor
    end
    % minimo local
    for p=1:np
        if fx(p,1)<fxpl(p,1);
            fxpl(p,1) = fx(p,1); %remplazo el valor del mejor local
            x1pl(p,1) = x1p(p,1); %remplazo la posicion del mejor local
            x2pl(p,1) = x2p(p,1); %remplazo la posicion del mejor local
            x3pl(p,1) = x3p(p,1); %remplazo la posicion del mejor local
        end
    end
    %% Grafica
    plot(fx, x1p, x2p, x3p, 'b.', fx, x1pg, x2pg, x3pg, 'go')
    axis([-100 100 -100 100 -100 100]);
    title(['x1pg= ' num2str(x1pg) ' x2pg= ' num2str(x2pg) ' x3pg= ' num2str(x3pg)]);
    xlabel('x')
    ylabel('y')
    pause(.1);
    %% Ecuaciones de Movimineto
    vx1 = vx1+c1*rand()*(x1pg-x1p)+c2*rand()*(x1pl-x1p); % la velocidad
    x1p = vx1 + x1p;
    vx2 = vx2+c1*rand()*(x2pg-x2p)+c2*rand()*(x2pl-x2p); % la velocidad
    x2p = vx2 + x2p;
    vx3 = vx3+c1*rand()*(x3pg-x3p)+c2*rand()*(x3pl-x3p); % la velocidad
    x3p = vx3 + x3p;
end

fx= 4*x1pg+12*x2pg+2*x3pg

