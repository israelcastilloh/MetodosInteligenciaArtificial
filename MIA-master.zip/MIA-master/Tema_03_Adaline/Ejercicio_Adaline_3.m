%% Problema Tarea 3: Adaline
clear all;
close all;
clc;
format bank
%% Esto es para ver que funciona, pero no es necesario en el modelo
datos = xlsread('regresion','Problema 3','A2:D201');
X1 = datos(:,1);
X2 = datos(:,2);
X3 = datos(:,3);
Y = datos(:,4);
% for i=1:5
% grado = i;
grado = 2;
%% M�nimos Cuadrados
m = size(X1,1); %Cantidad de Datos del Problema
% Armar X*
%Xa = ones(m,1); %Columna de Unos
%for k = 1:2 %el 4 es para una regresi�n de grado 4 (poner un grado equivocado menor no da un resultado cercano, y si es muy grande falla o hace overfitting)
    Xa = func_polinomio([X1,X2,X3],grado); %X asterisco
    Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
    Yg_mc = Xa*Wmc; %Y estimada (gorrito)
    E = Y-Yg_mc; %Error
%     J(i,1) = E'*E/(2*m); %La funcion de Costo
    J = E'*E/(2*m); %La funcion de Costo
% end
% figure(1)
% subplot(2,1,1)
% plot(X1,Y,'b.',X1,Yg_mc,'r.')
% title('Comparativo de Y y Y Estimada')
% xlabel('X')
% ylabel('Y')
% subplot(2,1,2)
% plot(J,'b')
% title('Grafica de codo con 3 Variables')
% xlabel('Grado del Polinomio')
% ylabel('J(X,W)')
J1 = J
%% Gradiente Descendente
%Xa = ones(m,1);
m = size(X1,1); %Cantidad de Datos del Problema
%for k = 1:2
    Xa = func_polinomio([X1,X2,X3],grado); %X asterisco
%end
Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
Wgd = rand(size(Xa,2),1); %Pesos iniciales
Eta = 0.00000000001; %Velocidad de Convergencia

for k=1:1000000 %numero de iteraciones es un problema en Gradiente descendente
    Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes
    E = Y-Yg_gd;
    J(k,1) = (E'*E)/(2*m);
    dJdW = -E'*Xa/m;
    Wgd = Wgd-Eta*dJdW';
end
Yg_mc = Xa*Wmc; %Y estimada (gorrito)
Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes
% figure(2)
% subplot(2,1,1)
 plot(X1,Y,'b.',X1,Yg_mc,'r.',X1,Yg_gd,'g.')
% title('Comparativo Gradiente Descendente y Minimos Cuadrados')
% xlabel('X')
% ylabel('Y')
% subplot(2,1,2)
 plot(J,'r.')
% title('J del Gradiente')
% xlabel('Grado del Polinomio')
% ylabel('J(X,W)')
[Wmc Wgd]; %Coeficientes de los Modelos
rt = [func_polinomio([5,6,7],grado)]'; %Para comprobar
a = sum(times(Wmc,rt));
b = sum(times(Wgd,rt));
[a,b];
%% Comparaci�n de Modelos
format long
disp('J de Minimos Cuadrados')
disp(J1) %J de Minimos Cuadrados
disp('J de Gradiente Descendente')
disp(J(end,1)) %J de Gradiente Descendente
Jmejor = min([J1,J(end,1)])