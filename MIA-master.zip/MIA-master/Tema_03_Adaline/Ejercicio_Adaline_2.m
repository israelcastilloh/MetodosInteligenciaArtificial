%% Problema Tarea 2: Adaline
clear all;
close all;
clc;
format bank
%% Esto es para ver que funciona, pero no es necesario en el modelo
datos = xlsread('regresion','Problema 2','A2:C201');
X1 = datos(:,1);
X2 = datos(:,2);
Y = datos(:,3);
% for i=1:5
% grado = i;
grado = 2;
%% M�nimos Cuadrados
m = size(X1,1); %Cantidad de Datos del Problema
% Armar X*
Xa = ones(m,1); %Columna de Unos
for k = 1:2 %el 4 es para una regresi�n de grado 4 (poner un grado equivocado menor no da un resultado cercano, y si es muy grande falla o hace overfitting)
    Xa = func_polinomio([X1,X2],grado); %X asterisco
    Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
    Yg_mc = Xa*Wmc; %Y estimada (gorrito)
    E = Y-Yg_mc; %Error
    J = E'*E/(2*m); %La funcion de Costo
 end
figure(1)
plot(J,'b')
title('Grafica de codo con 2 Variables')
xlabel('Grado del Polinomio')
ylabel('J(X,W)')
J1 = J
