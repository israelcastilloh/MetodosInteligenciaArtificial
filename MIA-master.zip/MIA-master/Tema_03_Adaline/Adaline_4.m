%% Primer Modelo Adaline
clear all;
close all;
clc;
%% Esto es para ver que funciona, pero no es necesario en el modelo
datos = xlsread('BD_Adaline','Hoja1','A2:C25')
X1 = datos(:,2);
X2 = datos(:,1);
Y = datos(:,3);
%% M�nimos Cuadrados
m = size(X1,1); %Cantidad de Datos del Problema
% Armar X*
Xa = ones(m,1); %Columna de Unos
Xa = [Xa X1 X1.^2 X2 X1.*X2 (X1.^2).*X2]; %X asterisco    
Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
Yg_mc = Xa*Wmc; %Y estimada (gorrito)
E = Y-Yg_mc; %Error
J = E'*E/(2*m); %La funcion de Costo
%% Gradiente Descendente
Xa = ones(m,1);
m = size(X1,1); %Cantidad de Datos del Problema
Xa = ones(m,1); %Columna de Unos
Xa = [Xa X1 X1.^2 X2 X1.*X2 (X1.^2).*X2]; %X asterisco
Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
Wgd = rand(size(Xa,2),1); %Pesos iniciales
Eta = 0.000000000002; %Velocidad de Convergencia

for k=1:10000 %numero de iteraciones es un problema en Gradiente descendente
    Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes
    E = Y-Yg_gd;
    J1(k,1) = (E'*E)/(2*m);
    dJdW = -E'*Xa/m;
    Wgd = Wgd-Eta*dJdW';
end
Yg_mc = Xa*Wmc; %Y estimada (gorrito)
Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes

[Wmc Wgd] %Coeficientes de los Modelos
[J J1(end)]% Resultado Y