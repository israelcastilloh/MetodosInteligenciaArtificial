%% Primer Modelo Adaline
clear all;
close all;
clc;
%% Esto es para ver que funciona, pero no es necesario en el modelo
X = rand(100,1);
Y = 10 + 3*X + X.^2 + 4*X.^4;
%% M�nimos Cuadrados
m = size(X,1); %Cantidad de Datos del Problema
% Armar X*
Xa = ones(m,1); %Columna de Unos
for k = 1:4 %el 4 es para una regresi�n de grado 4 (poner un grado equivocado menor no da un resultado cercano, y si es muy grande falla o hace overfitting)
    Xa = [Xa X.^k]; %X asterisco
    Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
    Yg_mc = Xa*Wmc; %Y estimada (gorrito)
    E = Y-Yg_mc; %Error
    J(k,1) = E'*E/(2*m); %La funcion de Costo
end
figure(1)
subplot(2,1,1)
plot(X,Y,'b.',X,Yg_mc,'r.')
title('Comparativo de Y y Y Estimada')
xlabel('X')
ylabel('Y')
subplot(2,1,2)
plot(J,'b')
xlabel('Grado del Polinomio')
ylabel('J(X,W)')
%% Gradiente Descendente
Xa = ones(m,1);
m = size(X,1); %Cantidad de Datos del Problema
for k = 1:2
    Xa = [Xa X.^k]; %X asterisco
end
Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
Wgd = rand(size(Xa,2),1); %Pesos iniciales
Eta = 1.2; %Velocidad de Convergencia

for k=1:10000 %numero de iteraciones es un problema en Gradiente descendente
    Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes
    E = Y-Yg_gd;
    J(k,1) = (E'*E)/(2*m);
    dJdW = -E'*Xa/m;
    Wgd = Wgd-Eta*dJdW';
end
Yg_mc = Xa*Wmc; %Y estimada (gorrito)
Yg_gd = Xa*Wgd; %Y estimada de gradiente descendentes
figure(2)
subplot(2,1,1)
plot(X,Y,'b.',X,Yg_mc,'r.',X,Yg_gd,'g.')
title('Comparativo Gradiente Descendente y Minimos Cuadrados')
xlabel('X')
ylabel('Y')
subplot(2,1,2)
plot(J,'r.')
title('J del Gradiente')
xlabel('Grado del Polinomio')
ylabel('J(X,W)')
[Wmc Wgd] %Coeficientes de los Modelos