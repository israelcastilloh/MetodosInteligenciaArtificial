%% Problema Tarea 1: Adaline
clear all;
close all;
clc;
format bank
%% Esto es para ver que funciona, pero no es necesario en el modelo
datos = xlsread('regresion','Problema 1','A2:B201');
X = datos(:,1);
Y = datos(:,2);
%% M�nimos Cuadrados
m = size(X,1); %Cantidad de Datos del Problema
% Armar X*
Xa = ones(m,1); %Columna de Unos
for k = 1:2 %el 4 es para una regresi�n de grado 4 (poner un grado equivocado menor no da un resultado cercano, y si es muy grande falla o hace overfitting)
    %se pone hasta 4 para ver significancia de otros grados, pero al ver
    %que es 2, se gresa para obtener la J para el grado 2
    Xa = [Xa X.^k]; %X asterisco
    Wmc = inv(Xa'*Xa)*Xa'*Y; %Matriz de minimos cuadrados
    Yg_mc = Xa*Wmc; %Y estimada (gorrito)
    E = Y-Yg_mc; %Error
    J(k,1) = E'*E/(2*m); %La funcion de Costo
end
figure(1)
subplot(2,1,1)
plot(X,Y,'b.',X,Yg_mc,'r.')
title('Comparativo de Y y Y Estimada')
xlabel('X')
ylabel('Y')
subplot(2,1,2)
plot(J,'b')
xlabel('Grado del Polinomio')
ylabel('J(X,W)')
J1 = min(J)