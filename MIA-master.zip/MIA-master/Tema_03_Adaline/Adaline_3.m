%% Segundo Modelo Adaline, para predicci�n
clear all;
close all;
clc;
%% Carga de datos
res=downloadValues('CMG','03/10/2015','03/10/2016','d','history');
precios=res.AdjClose;
%% Rezagos
nrez=20;
X=[];
for k=0:nrez
    X = [X, precios(nrez+1-k:end-k)];
end
Y = X(:,1);
Xa = [ones(size(X,1),1) X(:,2:end)];
ntrain = round(0.6*size(Xa,1));
Xa_train = Xa(1:ntrain,:);
Y_train = Y(1:ntrain,:);
Xa_test = Xa(ntrain+1:end,:);
Y_test = Y(ntrain+1:end,:);
Wmc = inv(Xa'*Xa)*Xa'*Y; %Pesos por m�nimos cuadrados
Yg_mc = Xa*Wmc; %Y estimdada
figure(1)
plot([1:size(Y,1)]',Y,'b-',[1:size(Yg_mc,1)],Yg_mc,'r-')
Wmc = inv(Xa_train'*Xa_train)*Xa_train'*Y_train; %Pesos por m�nimos cuadrados
Yg_mc = Xa*Wmc; %Y estimdada
figure(2)
plot([1:size(Y,1)]',Y,'b-',[1:size(Yg_mc,1)],Yg_mc,'r-')
%% 
Yg_rec = Xa_train*Wmc;
Xtemp = Xa_train(end,:);
for k=ntrain+1:size(Xa,1);
    Xtemp = [1 Yg_rec(k-1,1) Xtemp(:,2:end-1)];
    Yg_rec(k,1) = Xtemp*Wmc;
end
figure(3)
plot([1:size(Y,1)]',Y,'b-',[1:size(Yg_mc,1)],Yg_mc,'r-',[1:size(Yg_rec,1)],Yg_rec,'g-')
legend('Precios','Estimado en k+1','estimado en K+n')
grid

%vma�ana = [1 625 615 650] %nrez = 3
%vpasado_ma�ana = [1 vma�ana 625 615] %nrez = 3