%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ALGORITMO DE TRADING USANDO UN PROMEDIO MOVIL %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;
clc;
%% Obteniendo los datos que ser?n usandos para simular el algoritmo de trading
hoy=datestr(date,23);
inicio=datestr(datenum(date)-365,23);
data = downloadValues('GRUMAB.MX',inicio,hoy,'d','history');
precios = data.AdjClose; %Seleccionar los precios de cierre

%% Algoritmo de trading basado en un promedio movil
npm = 18; %Numero de dias usados para calcular el promedio movil
cap = 10000*ones(size(precios)); %Capital inicial a invertir
nac = 0*ones(size(precios)); %Numero de acciones disponibles al inicio de la simulaci?n
com = 0.0000; %Comision por operacion

% Simulacion del algoritmo
for t = 0:size(precios,1)-npm
    pm(npm+t,1) = mean(precios(t+1:npm+t,1)); %Calculando el promedio movil
    
    if pm(npm+t,1)<precios(npm+t,1)
        % Comprar, si el promedio movil es m?s grande que el precio actual
        u = floor((cap(npm+t,1))/((1+com)*precios(npm+t,1)));
    else
        % Vender, si el promedio movil es m?s peque?o que el precio actual
        u = -nac(npm+t,1);
    end
    nac(npm+t+1,1) = nac(npm+t,1)+u;
    cap(npm+t+1,1) = cap(npm+t,1)-precios(npm+t,1)*u-com*precios(npm+t,1)*abs(u);
end

%% Visualizacion de los resultados
T = (1:size(precios,1))';
figure(1);
subplot(4,1,1);
plot(T,precios,'b-',T(npm:end),pm(npm:end),'r--');
title(sprintf('Promedio Movil a %d d�as',npm)),xlabel('# D�as'), ylabel('Precio');
legend('Precio','Promedio','Location','NorthEastOutside');
grid;
subplot(4,1,2);
plot(T,nac(1:end-1,1),'b-');
xlabel('# D�as'), ylabel('# Acciones');
legend('# Acciones','Location','NorthEastOutside');
grid;
subplot(4,1,3);
plot(T,cap(1:end-1,1),'b-');
xlabel('# D�as'), ylabel('$');
legend('Capital','Location','NorthEastOutside');
grid;
subplot(4,1,4);
plot(T,100*(cap(1:end-1,1)+precios.*nac(1:end-1,1)-cap(1,1))/cap(1,1),'b-');
xlabel('# D�as'), ylabel('Rendimiento (%)');
legend('Total','Location','NorthEastOutside');
grid;