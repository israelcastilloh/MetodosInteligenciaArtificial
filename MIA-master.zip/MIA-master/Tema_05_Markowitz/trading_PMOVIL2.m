%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ALGORITMO DE TRADING USANDO UN PROMEDIO MOVIL %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function y = trading_PMOVIL2(precios,pon1,pon2,pon3)
    %% Algoritmo de trading basado en un promedio movil
    npm = 3; %Numero de dias usados para calcular el promedio movil
    cap = 3000*ones(size(precios)); %Capital inicial a invertir
    nac = 0*ones(size(precios)); %Numero de acciones disponibles al inicio de la simulaci?n
    com = 0.0029; %Comision por operacion

    % Simulacion del algoritmo
    for t = 0:size(precios,1)-npm
        pm(npm+t,1) = sum([pon1;pon2;pon3].*(precios(t+1:npm+t,1))); %Calculando el promedio movil
        if pm(npm+t,1)<precios(npm+t,1)
            % Comprar, si el promedio movil es m?s grande que el precio actual
            u = floor((cap(npm+t,1))/((1+com)*precios(npm+t,1)));
        else
            % Vender, si el promedio movil es m?s peque?o que el precio actual
            u = -nac(npm+t,1);
        end
        nac(npm+t+1,1) = nac(npm+t,1)+u;
        cap(npm+t+1,1) = cap(npm+t,1)-precios(npm+t,1)*u-com*precios(npm+t,1)*abs(u);
    end
    %% Visualizacion de los resultados
    rendimiento = 100*(cap(1:end-1,1)+precios.*nac(1:end-1,1)-cap(1,1))/cap(1,1),'b-'
    y = rendimiento(end,1)
end