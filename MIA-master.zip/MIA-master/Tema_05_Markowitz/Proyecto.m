%% Obteniendo los datos que ser?n usandos para simular el algoritmo de trading
hoy=datestr(date,23);
inicio=datestr(datenum(date)-365,23);
data = downloadValues('GRUMAB.MX',inicio,hoy,'d','history');
precios = data.AdjClose; %Seleccionar los precios de cierre
%% BUscar la ventana �tima





%% MArcowits dice cuanto capital (cap)
trading_PMOVIL2(precios,.2,.5,.3) %% funcion objetivo del pso odnde las ponderaciones son las part�culas con la restirccon de que deben sumar entre max 1 y deben ser positivas