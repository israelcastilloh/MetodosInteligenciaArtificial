%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ALGORITMO DE TRADING USANDO UN PROMEDIO MOVIL %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function y=trading_PMovil2(precios,pon1,pon2,pon3,pon4,pon5,pon6,pon7,pon8,pon9,pon10,pon11,pon12,...
    pon13,pon14,pon15,pon16,pon17,pon18,pon19,pon20,pon21,pon22,pon23,pon24,pon25,pon26,pon27,pon28)
%%

%% Obteniendo los datos que ser�n usandos para simular el algoritmo de trading

%% Algoritmo de trading basado en un promedio movil
npm = 28; %N�mero de d�as usados para calcular el promedio m�vil
cap = 1000000*0.2154*ones(size(precios)); %Capital inicial a invertir
nac = 0*ones(size(precios)); %N�mero de acciones disponibles al inicio de la simulaci�n
com = 0.0029; %Comisi�n por operaci�n

pond=[pon1,pon2,pon3,pon4,pon5,pon6,pon7,pon8,pon9,pon10,pon11,pon12,...
    pon13,pon14,pon15,pon16,pon17,pon18,pon19,pon20,pon21,pon22,pon23,pon24,pon25,pon26,pon27,pon28];

% Simulaci�n del algoritmo
for t = 0:size(precios,1)-npm
    %pmp(npm+t,1) = sum(pond.*precios(t+1:npm+t,1)); %Calculando el promedio movil
    pmp(npm+t,1) = (pond*precios(t+1:npm+t,1))/(sum(pond));
    
    if pmp(npm+t,1)<precios(npm+t,1)
        % Comprar, si el promedio movil es m�s grande que el precio actual
        u = floor((cap(npm+t,1))/((1+com)*precios(npm+t,1)));
    else
        % Vender, si el promedio movil es m�s peque�o que el precio actual
        u = -nac(npm+t,1);
    end
    nac(npm+t+1,1) = nac(npm+t,1)+u;
    cap(npm+t+1,1) = cap(npm+t,1)-precios(npm+t,1)*u-com*precios(npm+t,1)*abs(u);
end

%% Visualizaci�n de los resultados
% T = (1:size(precios,1))';
% figure(1);
% subplot(4,1,1);
% plot(T,precios,'b-',T(npm:end),pm(npm:end),'r--');
% title(sprintf('Promedio Movil a %d d�as',npm)),xlabel('# dias'), ylabel('precio');
% legend('precio','promedio','Location','NorthEastOutside');
% grid;
% subplot(4,1,2);
% plot(T,nac(1:end-1,1),'b-');
% xlabel('# dias'), ylabel('# acciones');
% legend('# acciones','Location','NorthEastOutside');
% grid;
% subplot(4,1,3);
% plot(T,cap(1:end-1,1),'b-');
% xlabel('# dias'), ylabel('$');
% legend('capital','Location','NorthEastOutside');
% grid;
% subplot(4,1,4);
% plot(T,100*(cap(1:end-1,1)+precios.*nac(1:end-1,1)-cap(1,1))/cap(1,1),'b-');
% xlabel('# dias'), ylabel('rendimiento (%)');
% legend('Total','Location','NorthEastOutside');
% grid;

rendimiento=100*(cap(1:end-1,1)+precios.*nac(1:end-1,1)-cap(1,1))/cap(1,1);
y=rendimiento(end,1);
end
