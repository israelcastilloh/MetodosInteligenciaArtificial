%% RESULTADOS OBTENIDOS
close all;
clear all;
clc;
%% PASO 1: Ponderaciones de los activos
    % ASRUB = 0.2883              
    % ALPEKA = 0.3474
    % GUMAB =  0.3643  
%% PASO 2: VENTANAS OPTIMAS y RENDIMIENTO
    % ASRUB = 30 y 5.4096
    % ALPEKA = 28 y 39.6990
    % GRUMAB = 21 y -5.7399
%% PASO 3: PSO
%PSO_ASURB.MX, fx = 6.4524
%PSO_ALPEKA.MX, fx = 39.1129
%PSO_GRUMAB.MX, fx = 17.5000 %
%% PASO 4: COMPARACION DE RENDIMIENTOS

%Promedio Movil
format bank
r1 = 1000000*0.2883*((5.4096/100));
r2 = 1000000*0.3474*((39.6990/100));
r3 = 1000000*0.3643*((-5.7399/100));
rpm = r1+r2+r3

%PSO ponderado
format bank
p1 = 1000000*0.2883*((5.7313/100));
p2 = 1000000*0.3474*((39.1129/100));
p3 = 1000000*0.3643*((17.5000/100));
ppm = p1+p2+p3
