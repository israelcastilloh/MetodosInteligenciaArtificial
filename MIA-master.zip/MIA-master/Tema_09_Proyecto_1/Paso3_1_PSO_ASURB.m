%% PSO ASURB.MX
clear all;
close all;  
clc;
%% Obteniendo los datos que seran usando para simular el algoritmo de trading
data1=downloadValues('ASURB.MX','09/18/2017', '09/18/2018','d','history');
%data2=downloadValues('ALPEKA.MX','09/18/2017', '09/18/2018','d','history');
%data3=downloadValues('GRUMAB.MX','09/18/2017', '09/18/2018','d','history');
precios=[data1.AdjClose]; %Seleccionar los precios de cierre
 
np = 1200; %# de Particulas.
fxpg=100000; %Valor global
fxpL=ones(np,1)*fxpg; %desempeno mejor local, ones llena de 1
 
x1p=rand(np,1);
x1pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x1pL=x1p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx1=zeros(np,1); %VELOCIDAD INICIAL.
 
x2p=rand(np,1);
x2pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x2pL=x2p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx2=zeros(np,1); %VELOCIDAD INICIAL.
 
x3p=rand(np,1);
x3pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x3pL=x3p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx3=zeros(np,1); %VELOCIDAD INICIAL.
 
x4p=rand(np,1);
x4pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x4pL=x4p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx4=zeros(np,1); %VELOCIDAD INICIAL.
 
x5p=rand(np,1);
x5pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x5pL=x5p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx5=zeros(np,1); %VELOCIDAD INICIAL.
 
x6p=rand(np,1);
x6pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x6pL=x6p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx6=zeros(np,1); %VELOCIDAD INICIAL.
 
x7p=rand(np,1);
x7pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x7pL=x7p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx7=zeros(np,1); %VELOCIDAD INICIAL.
 
x8p=rand(np,1);
x8pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x8pL=x8p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx8=zeros(np,1); %VELOCIDAD INICIAL.
 
x9p=rand(np,1);
x9pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x9pL=x9p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx9=zeros(np,1); %VELOCIDAD INICIAL.
 
x10p=rand(np,1);
x10pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x10pL=x10p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx10=zeros(np,1); %VELOCIDAD INICIAL.
 
x11p=rand(np,1);
x11pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x11pL=x11p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx11=zeros(np,1); %VELOCIDAD INICIAL.
 
x12p=rand(np,1);
x12pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x12pL=x12p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx12=zeros(np,1); %VELOCIDAD INICIAL.
 
x13p=rand(np,1);
x13pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x13pL=x13p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx13=zeros(np,1); %VELOCIDAD INICIAL.
 
x14p=rand(np,1);
x14pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x14pL=x14p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx14=zeros(np,1); %VELOCIDAD INICIAL.
 
x15p=rand(np,1);
x15pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x15pL=x15p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx15=zeros(np,1); %VELOCIDAD INICIAL.
 
x16p=rand(np,1);
x16pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x16pL=x16p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx16=zeros(np,1); %VELOCIDAD INICIAL.
 
x17p=rand(np,1);
x17pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x17pL=x17p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx17=zeros(np,1); %VELOCIDAD INICIAL.
 
x18p=rand(np,1);
x18pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x18pL=x18p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx18=zeros(np,1); %VELOCIDAD INICIAL.
 
x19p=rand(np,1);
x19pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x19pL=x19p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx19=zeros(np,1); %VELOCIDAD INICIAL.
 
x20p=rand(np,1);
x20pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x20pL=x20p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx20=zeros(np,1); %VELOCIDAD INICIAL.

x21p=rand(np,1);
x21pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x21pL=x21p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx21=zeros(np,1); %VELOCIDAD INICIAL.

x22p=rand(np,1);
x22pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x22pL=x22p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx22=zeros(np,1); %VELOCIDAD INICIAL.

x23p=rand(np,1);
x23pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x23pL=x23p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx23=zeros(np,1); %VELOCIDAD INICIAL.

x24p=rand(np,1);
x24pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x24pL=x24p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx24=zeros(np,1); %VELOCIDAD INICIAL.

x25p=rand(np,1);
x25pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x25pL=x25p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx25=zeros(np,1); %VELOCIDAD INICIAL.

x26p=rand(np,1);
x26pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x26pL=x26p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx26=zeros(np,1); %VELOCIDAD INICIAL.

x27p=rand(np,1);
x27pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x27pL=x27p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx27=zeros(np,1); %VELOCIDAD INICIAL.

x28p=rand(np,1);
x28pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x28pL=x28p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx28=zeros(np,1); %VELOCIDAD INICIAL.

x29p=rand(np,1);
x29pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x29pL=x29p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx29=zeros(np,1); %VELOCIDAD INICIAL.

x30p=rand(np,1);
x30pg=0; %VALOR INICIAL DEL MEJOR GLOBAL.
x30pL=x30p; %POSICIONES DE LOS MEJORES INICIALES, AHORA: VALOR INICIAL.
vx30=zeros(np,1); %VELOCIDAD INICIAL.
 
 
c1=0.5; %VELOCIDAD DE CONVERGENCIA AL MEJOR GLOBAL.
c2=0.5; %VELOCIDAD DE CONVERGENCIA AL MEJOR LOCAL.
a=-100; %PENALIZACION
 
%% PSO.
for k=1:200 %ciclos
    %EVALUAR EL DESEMPENO.   
    for i=1:np
        fx(i,1)=-(trading_PMovil1(precios,x1p(i),x2p(i),x3p(i),x4p(i),...
        x5p(i),x6p(i),x7p(i),x8p(i),x9p(i),x10p(i),x11p(i),...
        x12p(i),x13p(i),x14p(i),x15p(i),x16p(i),x17p(i),x18p(i),...
        x19p(i),x20p(i),x21p(i),x22p(i),x23p(i),x24p(i),x25p(i),x26p(i),x27p(i),x28p(i),x29p(i),x30p(i))...
        +a*abs(x1p(i)+x2p(i)+x3p(i)+x4p(i)+x5p(i)+x6p(i)+x7p(i)+x8p(i)+x9p(i)+...
        x10p(i)+x11p(i)+x12p(i)+x13p(i)+x14p(i)+x15p(i)+x16p(i)+x17p(i)+x18p(i)+x19p(i)+...
        x20p(i)+x21p(i)+x22p(i)+x23p(i)+x24p(i)+x25p(i)+x26p(i)+x27p(i)+x28p(i)+x29p(i)+x30p(i)-1)+...
        a*max(x1p(i)-1,0)+a*max(x2p(i)-1,0)+a*max(x3p(i)-1,0)+a*max(x4p(i)-1,0)+a*max(x5p(i)-1,0)+a*max(x6p(i)-1,0)+a*max(x7p(i)-1,0)+a*max(x8p(i)-1,0)+a*max(x9p(i)-1,0)+...
        a*max(x10p(i)-1,0)+a*max(x11p(i)-1,0)+a*max(x12p(i)-1,0)+a*max(x13p(i)-1,0)+a*max(x14p(i)-1,0)+a*max(x15p(i)-1,0)+a*max(x16p(i)-1,0)+a*max(x17p(i)-1,0)+a*max(x18p(i)-1,0)+a*max(x19p(i)-1,0)+...
        a*max(x20p(i)-1,0)+a*max(x21p(i)-1,0)+a*max(x22p(i)-1,0)+a*max(x23p(i)-1,0)+a*max(x24p(i)-1,0)+a*max(x25p(i)-1,0)+a*max(x26p(i)-1,0)+a*max(x27p(i)-1,0)+a*max(x28p(i)-1,0)+a*max(x29p(i)-1,0)+a*max(x30p(i)-1,0)+...
        +a*max(-x1p(i),0)+a*max(-x2p(i),0)+a*max(-x3p(i),0)+a*max(-x3p(i),0)+a*max(-x4p(i),0)...
        +a*max(-x5p(i),0)+a*max(-x7p(i),0)+a*max(-x8p(i),0)+a*max(-x9p(i),0)+a*max(-x10p(i),0)...
        +a*max(-x11p(i),0)+a*max(-x12p(i),0)+a*max(-x13p(i),0)+a*max(-x14p(i),0)+a*max(-x15p(i),0)...
        +a*max(-x16p(i),0)+a*max(-x17p(i),0)+a*max(-x18p(i),0)+a*max(-x19p(i),0)+a*max(-x20p(i),0)...
        +a*max(-x21p(i),0)+a*max(-x22p(i),0)+a*max(-x23p(i),0)+a*max(-x24p(i),0)+a*max(-x25p(i),0)...
        +a*max(-x26p(i),0)+a*max(-x27p(i),0)+a*max(-x28p(i),0)+a*max(-x29p(i),0)+a*max(-x30p(i),0)); 
    end
    %DETERMINAR EL MEJOR GLOBAL.
    [val,ind]=min(fx);
    if val<fxpg
        x1pg=x1p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x2pg=x2p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x3pg=x3p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x4pg=x4p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x5pg=x5p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x6pg=x6p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x7pg=x7p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x8pg=x8p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x9pg=x9p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x10pg=x10p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x11pg=x11p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x12pg=x12p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x13pg=x13p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x14pg=x14p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x15pg=x15p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x16pg=x16p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x17pg=x17p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x18pg=x18p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x19pg=x19p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x20pg=x20p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x21pg=x21p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x22pg=x22p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x23pg=x23p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x24pg=x24p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x25pg=x25p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x26pg=x26p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x27pg=x27p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x28pg=x28p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x29pg=x29p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        x30pg=x30p(ind,1); %ACTUALIZA LA POSICION DEL MEJOR GLOBAL.
        
        fxpg=val; %ACTUALIZA EL DESEMPE?O DEL MEJOR GLOBAL.
    end
    %DETERMINAR LOS MEJOR ES LOCALES.
    for p=1:np
        if fx(p,1)<fxpL(p,1)
            fxpL(p,1)=fx(p,1); %ACTUALIZA EL DESEMPENO DEL MEJOR LOCAL.
            x1pL(p,1)=x1p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x2pL(p,1)=x2p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x3pL(p,1)=x3p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x4pL(p,1)=x4p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x5pL(p,1)=x5p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x6pL(p,1)=x6p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x7pL(p,1)=x7p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x8pL(p,1)=x8p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x9pL(p,1)=x9p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x10pL(p,1)=x10p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x11pL(p,1)=x11p(p,1); %ACTUALIZA LA POSICION DEL MEJOR LOCAL.
            x12pL(p,1)=x12p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x13pL(p,1)=x13p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x14pL(p,1)=x14p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x15pL(p,1)=x15p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x16pL(p,1)=x16p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x17pL(p,1)=x17p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x18pL(p,1)=x18p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x19pL(p,1)=x19p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x20pL(p,1)=x20p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x21pL(p,1)=x21p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x22pL(p,1)=x22p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x23pL(p,1)=x23p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x24pL(p,1)=x24p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x25pL(p,1)=x25p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x26pL(p,1)=x26p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x27pL(p,1)=x27p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
            x28pL(p,1)=x28p(p,1); %ACTUALIZA EL POSICION DEL MEJOR LOCAL.
        end           
    end
    %ECUACIONES DE MOVIMIENTO.
    vx1=vx1+c1*rand()*(x1pg-x1p)+c2*rand()*(x1pL-x1p); %velocidad actualizada.
    x1p=x1p+vx1; %posicion actualizada
    
    vx2=vx2+c1*rand()*(x2pg-x2p)+c2*rand()*(x2pL-x2p); 
    x2p=x2p+vx2; 
    
    vx3=vx3+c1*rand()*(x3pg-x3p)+c2*rand()*(x3pL-x3p); 
    x3p=x3p+vx3; 
    
    vx4=vx4+c1*rand()*(x4pg-x4p)+c2*rand()*(x4pL-x4p); 
    x4p=x4p+vx4; 
    
    vx5=vx5+c1*rand()*(x5pg-x5p)+c2*rand()*(x5pL-x5p); 
    x5p=x5p+vx5; 
    
    vx6=vx6+c1*rand()*(x6pg-x6p)+c2*rand()*(x6pL-x6p); 
    x6p=x6p+vx6; 
    
    vx7=vx7+c1*rand()*(x7pg-x7p)+c2*rand()*(x7pL-x7p); 
    x7p=x7p+vx7; 
    
    vx8=vx8+c1*rand()*(x8pg-x8p)+c2*rand()*(x8pL-x8p); 
    x8p=x8p+vx8; 
    
    vx9=vx9+c1*rand()*(x9pg-x9p)+c2*rand()*(x9pL-x9p); 
    x9p=x9p+vx9; 
    
    vx10=vx10+c1*rand()*(x10pg-x10p)+c2*rand()*(x10pL-x10p); 
    x10p=x10p+vx10; 
    
    vx11=vx11+c1*rand()*(x11pg-x11p)+c2*rand()*(x11pL-x11p); 
    x11p=x11p+vx11; 
    
    vx12=vx12+c1*rand()*(x12pg-x12p)+c2*rand()*(x12pL-x12p); 
    x12p=x12p+vx12; 
    
    vx13=vx13+c1*rand()*(x13pg-x13p)+c2*rand()*(x13pL-x13p);
    x13p=x13p+vx13; 
    
    vx14=vx14+c1*rand()*(x14pg-x14p)+c2*rand()*(x14pL-x14p); 
    x14p=x14p+vx14; 
    
    vx15=vx15+c1*rand()*(x15pg-x15p)+c2*rand()*(x15pL-x15p); 
    x15p=x15p+vx15; 
    
    vx16=vx16+c1*rand()*(x16pg-x16p)+c2*rand()*(x16pL-x16p); 
    x16p=x16p+vx16; 
    
    vx17=vx17+c1*rand()*(x17pg-x17p)+c2*rand()*(x17pL-x17p); 
    x17p=x17p+vx17; 
    
    vx18=vx18+c1*rand()*(x18pg-x18p)+c2*rand()*(x18pL-x18p); 
    x18p=x18p+vx18; 
    
    vx19=vx19+c1*rand()*(x19pg-x19p)+c2*rand()*(x19pL-x19p); 
    x19p=x19p+vx19; 
    
    vx20=vx20+c1*rand()*(x20pg-x20p)+c2*rand()*(x20pL-x20p); 
    x20p=x20p+vx20;
    
    vx21=vx21+c1*rand()*(x21pg-x21p)+c2*rand()*(x21pL-x21p); 
    x21p=x21p+vx21; 
    
    vx22=vx22+c1*rand()*(x22pg-x22p)+c2*rand()*(x22pL-x22p); 
    x22p=x22p+vx22; 
    
    vx23=vx23+c1*rand()*(x23pg-x23p)+c2*rand()*(x23pL-x23p);
    x23p=x23p+vx23; 
    
    vx24=vx24+c1*rand()*(x24pg-x24p)+c2*rand()*(x24pL-x24p); 
    x24p=x24p+vx24; 
    
    vx25=vx25+c1*rand()*(x25pg-x25p)+c2*rand()*(x25pL-x25p); 
    x25p=x25p+vx25; 
    
    vx26=vx26+c1*rand()*(x26pg-x26p)+c2*rand()*(x26pL-x26p); 
    x26p=x26p+vx26; 
    
    vx27=vx27+c1*rand()*(x27pg-x27p)+c2*rand()*(x27pL-x27p); 
    x27p=x27p+vx27; 
    
    vx28=vx28+c1*rand()*(x28pg-x28p)+c2*rand()*(x28pL-x28p); 
    x28p=x28p+vx28; 
    
    vx29=vx29+c1*rand()*(x29pg-x29p)+c2*rand()*(x29pL-x29p); 
    x29p=x29p+vx29; 
    
    vx30=vx30+c1*rand()*(x30pg-x30p)+c2*rand()*(x30pL-x30p); 
    x30p=x30p+vx30;
end
fx = trading_PMovil1(precios,x1pg,x2pg,x3pg,x4pg,x5pg,x6pg,x7pg,x8pg,x9pg,x10pg,x11pg,x12pg,x13pg,x14pg,x15pg,...
    x16pg,x17pg,x18pg,x19pg,x20pg,x21pg,x22pg,x23pg,x24pg,x25pg,x26pg,x27pg,x28pg,x29pg,x30pg)