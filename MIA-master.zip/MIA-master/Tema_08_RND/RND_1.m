%% Redes Neuronales Dinamicas 1: Analisis de Series de Tiempo
clear all %limpiar Workplace
close all %limpia ventanas
clc %limpia command window
%% Cargar Datos
load RNCDatos4.mat;
Y = IPCfinal(:,5)';
U = BMV_17final(:,5)'; %Las entradas
%% Transformacion de los Datos
% Las paqueter�a de redes neuronales din�micas usa matrices de celdas
for k=1:size(Y,2)
    Yc{:,k} = Y(:,k);%Transforma la matriz Y en celdas
    Uc{:,k} = U(:,k);%Transforma la matriz U en celdas
end
%% Conjunto de Entrenamiento y Prueba
ndat = round(0.9*size(Yc,2));
Yctrain = Yc(:,1:ndat);
Uctrain = Uc(:,1:ndat);
Ycprueba = Yc(:,ndat+1:end);
Ucprueba = Uc(:,ndat+1:end);
%% Creacion de la Red Neuronal Dinamica
nrez = 5;%numero de rezagos
noc = 10;%numero de neuronas en la capa oculta
red = narxnet(1:nrez,1:nrez,noc);%red neuronal dinamica (numero de rezagos activos de y, numero de rezagosactivos de u, capas ocultas)
%red = narxnet([1 3 4 5],[2 3 4 5],noc);%alternativa de modelo
[Us,Ui,Yi,Ys]= preparets(red,Uctrain,{},Yctrain);%el conjunto que se le dara de entrenamiento lo parte en 2 y es con lo que empezara a construir el modelo
red = train(red,Us,Ys,Ui,Yi);
Yg_train = red(Us,Ui,Yi);
figure(1)
plotresponse(Ys,Yg_train)
%% Simulaci�n con datos de prueba
[Us,Ui,Yi,Ys]= preparets(red,Ucprueba,{},Ycprueba);%el conjunto que se le dara de entrenamiento lo parte en 2 y es con lo que empezara a construir el modelo
Yg_prueba = red(Us,Ui,Yi);
figure(2)
plotresponse(Ys,Yg_prueba)
%view(red)
%% Cerrando el lazo de la salida a la entrada
redc = closeloop(red);
[Us,Ui,Yi,Ys]= preparets(redc,Ucprueba,{},Ycprueba);%el conjunto que se le dara de entrenamiento lo parte en 2 y es con lo que empezara a construir el modelo
Ygc_prueba = redc(Us,Ui,Yi);
figure(3)
plotresponse(Ys,Ygc_prueba)
%view(redc)
%% Remover los Rezagos y Mover el Modelo a Futuro
redcnr = removedelay(redc);
[Us,Ui,Yi,Ys]= preparets(redcnr,Ucprueba,{},Ycprueba);%el conjunto que se le dara de entrenamiento lo parte en 2 y es con lo que empezara a construir el modelo
Ygcnr_prueba = redcnr(Us,Ui,Yi);
figure(4)
plotresponse(Ys,Ygcnr_prueba)
perform(redc,cell2mat(Ys),cell2mat(Yg_prueba))%Calcula la funci�n J
%view(redcnr)